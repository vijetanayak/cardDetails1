import React from "react";
import './App.css';
import CardDetails from "./CardDetails";

function App() {
  const cardSubmit=(data)=>{
    alert(JSON.stringify(data))
  }
  return (
    <div >
      <CardDetails onSubmit={cardSubmit} />
  
     
    </div>
  );
}

export default App;
