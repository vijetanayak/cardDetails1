
import React, { useState } from 'react';
import { AutoTabProvider } from 'react-auto-tab'
import Cards from "react-credit-cards";
import "react-credit-cards/es/styles-compiled.css"; 
import CreditCardInput from 'react-credit-card-input';


function CardDetails({ onSubmit }) {

  // state = {
  //   cardName: "",
  //   cardMonth: "",
  //   cardYear: "",
  //   cardExpiry: "",
  //   cardCVV: ""
  // }
  const [cardName, setCardName] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [cardMonth, setCardMonth] = useState("")
  const [cardYear, setCardYear] = useState("")

  const [cardCVV, setCardCVV] = useState("")
  const [alertMsg, setAlertMsg] = useState("")
  const [alertMsgCardNumber, setAlertMsgCardNumber] = useState("")
  const [alertMsgCardCVV, setAlertMsgCardCVV] = useState("")
  const [cardDetails, setCardDetails] = useState([])
  const [isEnabled, setIsEnabled] = useState(false)
  const [data, setData] = useState({  
                    cvc: "",  
                 expiry: "",  
                 name: "",  
                 number: "" ,
});



  //   useEffect(() => {
  //     alert(JSON.stringify(msg))
  // })


  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   alert(cardDetails);
  //     setCardDetails([cardName, cardYear,cardCVV,cardMonth,cardNumber]) 
  //     console.log(cardDetails)


  // };

  const handleSubmit = (event) => {
    event.preventDefault();
    setCardDetails([cardName, cardYear, cardCVV, cardMonth, cardNumber])

    return alert(
      'Entered Values are: ' + "cardName:" + cardName + ',' +
      "cardYear:" + cardYear + ',' + "cardNumber:" +
      cardNumber + ',' + "cardCVV:" + cardCVV + ',' + "cardMonth:" + cardMonth
    );
  };

  const handleBlur = (e) => {

    if (cardMonth.length < 0 || cardYear.length < 0 || cardCVV.length < 1 || cardNumber.length < 1) {

      setIsEnabled(false)
    } else {
      setIsEnabled(true)
    }

    if (e.target.value === "") {

      setAlertMsg("Enter Mandatory field");
    } else {



      setAlertMsg("");
    }


  };
 const clear=()=>{
  setCardDetails([])

 }
//to add space in between input cardnumber
  const handleCardDisplay = () => {
    const rawText = [...cardNumber.split(' ').join('')] // Remove old space
    const creditCard = [] // Create card as array
    rawText.forEach((t, i) => {
        if (i % 4 === 0) creditCard.push(' ') // Add space
        creditCard.push(t)
    })
    return creditCard.join('') 
}
  const handleInputChange = (e) => {  
    setData({   
          ...data,   
          [e.target.name]: e.target.value  
   }); 
}; 

const addspace = (str, gapNo) => {  
  let newStr = " ";
  let len = str.length;
  for (let i = 0; i<len; i++) {
      newStr = newStr + str[i];
      while(newStr.length % (gapNo+1) === 0) {
          newStr = newStr + " ";
      } 
  }
  return newStr.trim(" ");
}; 



  // const buttonDisable = (e) => {
  //   if (cardDetails.length < 3) {

  //   setIsEnabled(false)
  //   } else {
  //     setIsEnabled(true)
  //   }
  // };




  // input=(e) =>{
  //    if (this.e.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);
  // }

  return (

    
    <div className="container-fluid" >
      <div className="row clearfix"  >
   

        <div className="ui fixed menu " style={{
          marginLeft: ' 0.5%',
          marginTop: '0.5%', width: '30%'
        }} >
           

          <div className="card">
        
            <div className="ui container center" style={{ marginRight: -10}}>
        
              <div className="container" >
          
      
                <div className="ui-main"   >
                <div className="col-lg-3 col-md-3 col-sm-10 ">
                <Cards    
             cvc={cardCVV}    
           expiry={cardMonth + cardYear}
             focus={data.focus}    
             name={cardName}    
             number={cardNumber} 
             
         / > 
         </div>
              
          
          
               
          <div className="col-lg-12 col-md-4 col-sm-12 " >
                  {/* <h4>Add CardDetails</h4> */}
                  <form onSubmit={handleSubmit}  >
                    <div className="form-group">
              
                      <label  style={{ marginTop: 13}}>Name on the card</label>
                      <input type="text"
                        className="form-control"
                        name="cardName"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        style={{ fontSize: 16, padding: 3, width: 290, marginTop: -5, height: 40, borderWidth: 2 }} aria-describedby="emailHelp" />

                    </div>
                    <div className="form-group">
                      <label>Card Number  </label>
                      <span style={{ color: 'red' }}> * </span>
                      
                      <input


                        type="tel"
                        className="form-control"
                        name="cardNumber"
                       
                        value={handleCardDisplay()}
                        maxLength={20}
                     

                        onChange={(e) => {
                          
                          setCardNumber(e.target.value)
                          setData({   
                            ...data,   
                            [e.target.name]: e.target.value  
                     }); }}
                    //     onChange={(e) => {
                    //       setCardNumber((v) => (e.target.validity.valid ? e.target.value : v))
                    //       setData({   
                    //         ...data,   
                    //         [e.target.name]: e.target.value  
                    //  }); 
                    //     }}

                        onBlur={(e) => {

                          if (cardMonth.length < 0 || cardYear.length < 0 || cardCVV.length < 1 || cardNumber.length < 1) {

                            setIsEnabled(false)
                          } else {
                            setIsEnabled(true)
                          }
                          if (e.target.value === "") {

                            setAlertMsgCardNumber("Enter Mandatory field");



                          } else {

                            setAlertMsgCardNumber("");

                          }
                        }}


                        style={{ fontSize: 16, padding: 3, width: 290, marginTop: -8, height: 40, borderWidth: 2 }} />
                      {/* <img src=
                      "https://media.geeksforgeeks.org/wp-content/uploads/20200716222246/Path-219.png" alt="" /> */}
                      <span style={{ fontSize: 12, color: 'red' }}>{alertMsgCardNumber}</span>
                    </div>
                    <div className="form-group">


                      <div className="row">
                        <div className="col-lg-6 col-md-8 col-sm-12">
                          <AutoTabProvider>
                            <label>Expiration Date </label>
                            <span style={{ color: 'red' }}> * </span>
                            <div style={{ border: '1px solid rgb(206 212 218)',  height: 40, marginTop: -8, borderWidth: 2,borderRadius:'0.25rem '}} >


                              <input
                                type="text"
                                name="month" maxLength={2}
                                
                                value={cardMonth}
                                pattern="[0-9]*"
                                // onChange={(e) => { 
                                //   setCardMonth((v) => (
                                //     e.target.validity.valid ? e.target.value : v )  )
                                // }}
                                onChange={(e) => { 
                                  if(e.target.value >=  1 && e.target.value<=12){
                                    setCardMonth((v) => (
                                      e.target.validity.valid ? e.target.value : v )  )
                                  }
                                  else{
                                    setCardMonth('')
                                  }
                                }

                                  }
                              
                                onBlur={handleBlur}
                                style={{ border: 'none',outline:'none',fontSize: 16, width: 40, marginLeft:29, height: 30,color: 'rgb(80 84 87)' }}  tabbable  />

                              <span>/</span>
                              <input type="text" name="year" maxLength={2}
                                value={cardYear}
                                pattern="[0-9]*"
                               
                             
                                onChange={(e) =>{
                                 
                                  if(e.target.value>=1 && e.target.value <=35){
                                  setCardYear((v) => (e.target.validity.valid ? e.target.value : v))
                                console.log(cardYear)}
                                  else{
                                    setCardYear('')
                                  }
                                }}

                                // onChange={(e) =>{
                                //   if({validateDate}){
                                //   setCardYear((v) => (e.target.validity.valid ? e.target.value : v))}
                                //   else{
                                //     setCardYear('')
                                //   }
                                // }}
                                onBlur={handleBlur}
                                style={{ border: 'none',outline:'none',fontSize: 16,  height: 30 ,marginLeft:15,width: 40,color: 'rgb(80 84 87)' }}  tabbable />

                            </div>
                            </AutoTabProvider>
                        </div>


                        {/* <div style={{ border: '1px solid #bbbbbb' }} >
                      <input type="text" id="exampleInputPassword1" maxLength={2} placeholder="MM*" style={{ fontSize: 12, margin: 4, width: 100, border: 'none' }} required />
                      <span>/</span>
                      <input type="text" id="exampleInputPassword1" maxLength={2}  placeholder="YY*" style={{ fontSize: 12, margin: 4, width: 100, border: 'none' }} required />
                    </div> */}
                        <div className="col-lg-5 col-md-4 col-sm-12  ">

                          <label>CVV </label>
                          <span style={{ color: 'red' }}> * </span>


                          <input type="text" 
                          name="cvc"
                          className="form-control"
                            value={cardCVV}
                            pattern="[0-9]*"
                            maxLength="3"
                            onChange={(e) =>
                              setCardCVV((v) => (e.target.validity.valid ? e.target.value : v))}
                            onBlur={(e) => {
                              if (cardMonth.length < 0 || cardYear.length < 0 || cardCVV.length < 1 || cardNumber.length < 1) {

                                setIsEnabled(false)
                              } else {
                                setIsEnabled(true)
                              }
                              if (e.target.value === "") {

                                setAlertMsgCardCVV("Enter Mandatory field");



                              } else {

                                setAlertMsgCardCVV("");

                              }
                            }}

                            style={{ fontSize: 16, marginTop: -1, height: 40, marginTop: -8, borderWidth: 2, width: 114 }} />

                        </div>



                      </div>
                      <div className='row'>

                        <div className="col-lg-6 col-md-4 col-sm-12  ">
                          <span style={{ fontSize: 12, color: 'red', marginTop: '-10px' }}>{alertMsg}</span>
                        </div>
                        <div className="col-lg-6 col-md-4 col-sm-12  ">
                          <span style={{ fontSize: 12, color: 'red', marginLeft: '-1px', marginTop: '-10px' }}>{alertMsgCardCVV}</span>
                        </div>

                      </div>
                    </div>



                    <div className="col-lg-12 col-md-4 col-sm-10  text-right">
                      <button type="reset" style={{ border: 'none', color: 'blue' ,marginRight:2 }} >Clear </button>

                      <button type="submit" className="btn btn-primary" style={{ margin: 4 ,marginRight:15}} disabled={!isEnabled}  >Submit</button>

                    </div>

                  </form>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>







  )

}
export default CardDetails;