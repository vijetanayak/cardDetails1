
import React, { useState } from 'react';


function CardDetails({ onSubmit }) {

  // state = {
  //   cardName: "",
  //   cardMonth: "",
  //   cardYear: "",
  //   cardExpiry: "",
  //   cardCVV: ""
  // }
  const [cardName, setCardName] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [cardMonth, setCardMonth] = useState("")
  const [cardYear, setCardYear] = useState("")

  const [cardCVV, setCardCVV] = useState("")
  const [alertMsg, setAlertMsg] = useState("")
  const [alertMsgCardNumber, setAlertMsgCardNumber] = useState("")
  const [alertMsgCardCVV, setAlertMsgCardCVV] = useState("")
  const [cardDetails, setCardDetails] = useState([])
  const [isEnabled, setIsEnabled] = useState(false)



  //   useEffect(() => {
  //     alert(JSON.stringify(msg))
  // })


  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   alert(cardDetails);
  //     setCardDetails([cardName, cardYear,cardCVV,cardMonth,cardNumber]) 
  //     console.log(cardDetails)


  // };

  const handleSubmit = (event) => {
    event.preventDefault();
    setCardDetails([cardName, cardYear, cardCVV, cardMonth, cardNumber])

    return alert(
      'Entered Values are: ' + "cardName:" + cardName + ',' + "cardYear:" + cardYear + ',' + "cardNumber:" + cardNumber + ',' + "cardCVV:" + cardCVV + ',' + "cardMonth:" + cardMonth
    );
  };

  const handleBlur = (e) => {

    if (cardMonth.length < 0 || cardYear.length < 0 || cardCVV.length < 1 || cardNumber.length < 1) {

      setIsEnabled(true)
    } else {
      setIsEnabled(true)
    }

    if (e.target.value === "") {

      setAlertMsg("Enter Mandatory field");
    } else {



      setAlertMsg("");
    }


  };

  // const buttonDisable = (e) => {
  //   if (cardDetails.length < 3) {

  //   setIsEnabled(false)
  //   } else {
  //     setIsEnabled(true)
  //   }
  // };




  // input=(e) =>{
  //    if (this.e.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);
  // }

  return (
    <div className="container-fluid" >
      <div className="row clearfix"  >

        <div className="ui fixed menu " style={{
          marginLeft: ' 5%',
          marginTop: '2%', width: '30%'
        }} >

          <div className="card">
            <div className="ui container center">
              <div className="container" >
                <div className="ui-main">
                  {/* <h4>Add CardDetails</h4> */}
                  <form onSubmit={handleSubmit} >
                    <div className="form-group">
                      <label >Name on the card</label>
                      <input type="text"
                        className="form-control"
                        name="cardName"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        style={{ fontSize: 12, padding: 3, width: 260, marginTop: -8, height: 40, borderWidth: 2 }} aria-describedby="emailHelp" />

                    </div>
                    <div className="form-group">
                      <label>Card Number  </label>
                      <span style={{ color: 'red' }}> * </span>
                      <input type="text"
                        className="form-control"
                        name="cardNumber"
                        pattern="[0-9]*"
                        value={cardNumber}
                        maxLength="16"
                        onChange={(e) => {
                          setCardNumber((v) => (e.target.validity.valid ? e.target.value : v))
                        }}
                        onBlur={(e) => {
                          if (e.target.value === "") {

                            setAlertMsgCardNumber("Enter Mandatory field");



                          } else {

                            setAlertMsgCardNumber("");

                          }
                        }}

                        style={{ fontSize: 12, padding: 3, width: 260, marginTop: -8, height: 40, borderWidth: 2 }} />
                      <span style={{ fontSize: 12, color: 'red' }}>{alertMsgCardNumber}</span>
                    </div>
                    <div className="form-group">


                      <div className="row">
                        <div className="col-lg-5 col-md-8 col-sm-12">
                          <label>Expiration Date </label>
                          <span style={{ color: 'red' }}> * </span>
                          <div style={{ border: '1px solid #bbbbbb', height: 40, marginTop: -8, borderWidth: 2 }} >


                            <input
                              type="text"
                              name="month" maxLength="2"
                              value={cardMonth}
                              pattern="[0-9]*"
                              onChange={(e) => {
                                setCardMonth((v) => (e.target.validity.valid ? e.target.value : v))
                              }}
                              onBlur={handleBlur}
                              style={{ border: 'none', width: 45, height: 30, }} />

                            <span>/</span>
                            <input type="text" name="year" maxLength="2"
                              value={cardYear}
                              pattern="[0-9]*"
                              onChange={(e) =>
                                setCardYear((v) => (e.target.validity.valid ? e.target.value : v))}
                              onBlur={handleBlur}
                              size="2" style={{ border: 'none', height: 30 }} />

                          </div>
                        </div>


                        {/* <div style={{ border: '1px solid #bbbbbb' }} >
                      <input type="text" id="exampleInputPassword1" maxLength={2} placeholder="MM*" style={{ fontSize: 12, margin: 4, width: 100, border: 'none' }} required />
                      <span>/</span>
                      <input type="text" id="exampleInputPassword1" maxLength={2}  placeholder="YY*" style={{ fontSize: 12, margin: 4, width: 100, border: 'none' }} required />
                    </div> */}
                        <div className="col-lg-4 col-md-4 col-sm-12  ">

                          <label>CVV </label>
                          <span style={{ color: 'red' }}> * </span>


                          <input type="text" className="form-control"
                            value={cardCVV}
                            pattern="[0-9]*"
                            maxLength="3"
                            onChange={(e) =>
                              setCardCVV((v) => (e.target.validity.valid ? e.target.value : v))}
                            onBlur={(e) => {
                              if (e.target.value === "") {

                                setAlertMsgCardCVV("Enter Mandatory field");



                              } else {

                                setAlertMsgCardCVV("");

                              }
                            }}

                            style={{ fontSize: 12, marginTop: -1, height: 43, marginTop: -8, borderWidth: 2 }} />

                        </div>



                      </div>
                      <div className='row'>
                      
                        <div className="col-lg-6 col-md-4 col-sm-12  ">
                          <span style={{ fontSize: 12, color: 'red', marginTop: '-10px' }}>{alertMsg}</span>
                        </div>
                        <div className="col-lg-6 col-md-4 col-sm-12  ">
                          <span style={{ fontSize: 12, color: 'red', marginLeft:'-31px',marginTop: '-10px' }}>{alertMsgCardCVV}</span>
                        </div>
                     
                      </div>
                    </div>



                    <div className="col-lg-12 col-md-4 col-sm-12  text-right">
                      <button type="reset" style={{ border: 'none', color: 'blue' }}>Clear </button>
                      <button type="submit" className="btn btn-primary" style={{ margin: 4, }}  >Submit</button>

                    </div>

                  </form>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

  )

}
export default CardDetails;